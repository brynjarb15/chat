#Read me
##Forritið keyrt
Þegar keyra á forritið þarf að hafa nýjustu útgáfu af Node.js í tölvunni. Þá þarf að opna command prompt glugga og ná í nauðsynlega pakka. Það er gert með því að keyra eftirfarandi skipun bæðí inn í möppu sem heitir client og í möppu sem heitir server:

* npm install


Þá þarf að kveikja á socket.io servernum en það er gert með því að gera þessa skipun inn í server möppunni:

* node chatserver.js


Þar á eftir þarf að opna annan command prompt glugga og keyra eftirfarandi skipun í client möppunni:

* ng serve


Þá er hægt að opna vafra að eigin vali og fara inn á slóðina [http://www.localhost:4200](http://www.localhost:4200) og opnast login síðan inn á chat appið.

Server skránni var breytt við vinnslu verkefnisins og fylgir hún því með verkefninu.
Commentað var við þá parta þar sem henni var breytt.